# Delivery 2021 11 26

## Description

Printing quality issue with Kylin.

The zip is containing a simplex example which print 600 DPI with same quality as on windows.

To run this example:
    - First open a terminal in the "600DPIExample" folder
    - Execute the command `export LD_LIBRARY_PATH=lib/`
    - Then `bin/simplex "usb:///dev/usb/lp0" 1`

## Folders description

The content of the delivery is: 

* `600DPIExample.zip` - The libevolis with a 600 DPI example